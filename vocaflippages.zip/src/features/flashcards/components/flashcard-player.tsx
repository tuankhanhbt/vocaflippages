// /* eslint-disable @next/next/no-img-element */
// "use client";

// import { useState } from "react";
// import { AnimatePresence, motion } from "framer-motion";
// import { ChevronLeft, ChevronRight, RotateCcw } from "lucide-react";
// import { Button } from "@/components/ui/button";
// import type { Flashcard } from "@/types/flashcard";

// interface FlashcardPlayerProps {
//   cards: Flashcard[];
//   deckTitle: string;
// }

// export function FlashcardPlayer({ cards, deckTitle }: FlashcardPlayerProps) {
//   const [currentIndex, setCurrentIndex] = useState(0);
//   const [completed, setCompleted] = useState(false);
//   const [isFlipped, setIsFlipped] = useState(false);
//   const [knownIds, setKnownIds] = useState<number[]>([]);

//   const currentCard = cards[currentIndex];

//   function resetCardFace() {
//     setIsFlipped(false);
//   }

//   function handlePrev() {
//     if (currentIndex === 0) {
//       return;
//     }

//     resetCardFace();
//     setCurrentIndex((value) => value - 1);
//   }

//   function handleNext() {
//     if (currentIndex >= cards.length - 1) {
//       return;
//     }

//     resetCardFace();
//     setCurrentIndex((value) => value + 1);
//   }

//   function handleResult(cardId: number, knowsCard: boolean) {
//     resetCardFace();

//     setKnownIds((current) => {
//       const next = new Set(current);

//       if (knowsCard) {
//         next.add(cardId);
//       } else {
//         next.delete(cardId);
//       }

//       return [...next];
//     });

//     if (currentIndex >= cards.length - 1) {
//       setCompleted(true);
//       return;
//     }

//     setCurrentIndex((value) => value + 1);
//   }

//   function restart() {
//     setCompleted(false);
//     setCurrentIndex(0);
//     setKnownIds([]);
//     resetCardFace();
//   }

//   if (completed) {
//     return (
//       <motion.div
//         animate={{ opacity: 1, scale: 1 }}
//         className="rounded-[2rem] border border-white/70 bg-white/92 p-10 text-center shadow-[0_28px_80px_rgba(15,23,42,0.12)]"
//         initial={{ opacity: 0, scale: 0.96 }}
//       >
//         <span className="text-6xl">🎉</span>
//         <h2 className="mt-6 text-4xl font-semibold tracking-tight text-slate-950">
//           Deck complete
//         </h2>
//         <p className="mt-4 text-base leading-8 text-slate-600">
//           You reviewed all {cards.length} cards in {deckTitle} and marked {knownIds.length} as
//           known.
//         </p>

//         <div className="mt-8 flex justify-center">
//           <Button className="min-h-13 gap-2" onClick={restart} type="button">
//             <RotateCcw size={16} />
//             Study again
//           </Button>
//         </div>
//       </motion.div>
//     );
//   }

//   return (
//     <div className="mx-auto flex w-full max-w-3xl flex-col gap-8">
//       <div className="space-y-3">
//         <div className="flex items-center justify-between text-sm font-medium text-slate-600">
//           <span>
//             Card {currentIndex + 1} / {cards.length}
//           </span>
//           <span>{knownIds.length} known</span>
//         </div>

//         <div className="h-3 overflow-hidden rounded-full bg-slate-200/80">
//           <motion.div
//             animate={{ width: `${((currentIndex + 1) / cards.length) * 100}%` }}
//             className="h-full rounded-full bg-[linear-gradient(90deg,#205781_0%,#33d1b1_100%)]"
//             initial={{ width: 0 }}
//           />
//         </div>
//       </div>

//       <div
//         className="aspect-[4/3] w-full [perspective:1200px]"
//         onClick={() => setIsFlipped((value) => !value)}
//       >
//         <AnimatePresence mode="wait">
//           <motion.div
//             key={`${currentCard.id}-${isFlipped ? "back" : "front"}`}
//             animate={{ opacity: 1, rotateY: 0 }}
//             className="h-full cursor-pointer"
//             exit={{ opacity: 0, rotateY: isFlipped ? 90 : -90 }}
//             initial={{ opacity: 0, rotateY: isFlipped ? -90 : 90 }}
//             transition={{ duration: 0.28, ease: "easeInOut" }}
//           >
//             {!isFlipped ? (
//               <div className="flex h-full flex-col justify-between rounded-[2.2rem] border border-white/70 bg-[linear-gradient(180deg,#ffffff_0%,#eef7ff_100%)] p-8 shadow-[0_28px_80px_rgba(15,23,42,0.12)]">
//                 <div className="flex items-center justify-between">
//                   <span className="rounded-full bg-[#205781]/10 px-4 py-2 text-xs font-semibold uppercase tracking-[0.24em] text-[#205781]">
//                     Tap to reveal
//                   </span>
//                   <span className="text-sm font-medium text-slate-500">
//                     {currentCard.frontContentType}
//                   </span>
//                 </div>

//                 <div className="flex flex-1 items-center justify-center">
//                   {currentCard.frontContentType === "IMAGE" && currentCard.frontImageUrl ? (
//                     <img
//                       alt={currentCard.backText}
//                       className="max-h-full max-w-full rounded-[1.6rem] object-cover shadow-[0_24px_45px_rgba(15,23,42,0.16)]"
//                       src={currentCard.frontImageUrl}
//                     />
//                   ) : (
//                     <h3 className="text-center text-4xl font-semibold tracking-tight text-slate-950 sm:text-6xl">
//                       {currentCard.frontText}
//                     </h3>
//                   )}
//                 </div>

//                 <p className="text-center text-sm text-slate-500">
//                   Front side of the card. Flip when you are ready.
//                 </p>
//               </div>
//             ) : (
//               <div className="flex h-full flex-col rounded-[2.2rem] border border-[#205781]/15 bg-[linear-gradient(180deg,#f8fbff_0%,#ffffff_100%)] p-8 shadow-[0_28px_80px_rgba(15,23,42,0.12)]">
//                 <div className="flex items-center justify-between">
//                   <span className="rounded-full bg-emerald-100 px-4 py-2 text-xs font-semibold uppercase tracking-[0.24em] text-emerald-700">
//                     Answer
//                   </span>
//                   <span className="text-sm font-medium text-slate-500">Tap to flip back</span>
//                 </div>

//                 <div className="mt-8 flex-1 space-y-6">
//                   <div>
//                     <p className="text-xs font-semibold uppercase tracking-[0.22em] text-slate-500">
//                       Meaning
//                     </p>
//                     <h3 className="mt-3 text-3xl font-semibold tracking-tight text-slate-950 sm:text-5xl">
//                       {currentCard.backText}
//                     </h3>
//                   </div>

//                   {currentCard.exampleText ? (
//                     <div className="rounded-[1.5rem] border border-slate-200 bg-slate-50/90 p-5">
//                       <p className="text-xs font-semibold uppercase tracking-[0.22em] text-slate-500">
//                         Example
//                       </p>
//                       <p className="mt-3 text-base leading-8 text-slate-700">
//                         {currentCard.exampleText}
//                       </p>
//                     </div>
//                   ) : null}

//                   {currentCard.noteText ? (
//                     <div className="rounded-[1.5rem] border border-[#205781]/12 bg-[#205781]/5 p-5">
//                       <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#205781]">
//                         Note
//                       </p>
//                       <p className="mt-3 text-sm leading-7 text-slate-700">
//                         {currentCard.noteText}
//                       </p>
//                     </div>
//                   ) : null}
//                 </div>
//               </div>
//             )}
//           </motion.div>
//         </AnimatePresence>
//       </div>

//       <div className="grid gap-3 sm:grid-cols-2">
//         <button
//           className="min-h-14 rounded-[1.35rem] bg-rose-50 px-6 text-sm font-semibold text-rose-700 transition hover:bg-rose-100"
//           onClick={(event) => {
//             event.stopPropagation();
//             handleResult(currentCard.id, false);
//           }}
//           type="button"
//         >
//           Don&apos;t know yet
//         </button>
//         <button
//           className="min-h-14 rounded-[1.35rem] bg-emerald-50 px-6 text-sm font-semibold text-emerald-700 transition hover:bg-emerald-100"
//           onClick={(event) => {
//             event.stopPropagation();
//             handleResult(currentCard.id, true);
//           }}
//           type="button"
//         >
//           Got it
//         </button>
//       </div>

//       <div className="flex justify-center gap-3">
//         <Button
//           className="min-h-11 gap-2"
//           disabled={currentIndex === 0}
//           onClick={handlePrev}
//           type="button"
//           variant="secondary"
//         >
//           <ChevronLeft size={16} />
//           Previous
//         </Button>
//         <Button
//           className="min-h-11 gap-2"
//           disabled={currentIndex === cards.length - 1}
//           onClick={handleNext}
//           type="button"
//           variant="secondary"
//         >
//           Next
//           <ChevronRight size={16} />
//         </Button>
//       </div>
//     </div>
//   );
// }
/* eslint-disable @next/next/no-img-element */
"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ChevronLeft, ChevronRight, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { getApiErrorMessage } from "@/lib/api-error";
import { studySessionService } from "@/services/study-session.service";
import type {
  FinishStudySessionResponse,
  Flashcard,
  ReviewRating,
} from "@/types/flashcard";

interface FlashcardPlayerProps {
  cards: Flashcard[];
  deckId: number | string;
  deckTitle: string;
}

export function FlashcardPlayer({
  cards,
  deckId,
  deckTitle,
}: FlashcardPlayerProps) {
  const [sessionId, setSessionId] = useState<number | null>(null);
  const [studyCards, setStudyCards] = useState<Flashcard[]>(cards);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [completed, setCompleted] = useState(false);
  const [summary, setSummary] = useState<FinishStudySessionResponse | null>(null);
  const [isStarting, setIsStarting] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  const currentCard = studyCards[currentIndex];

  useEffect(() => {
    let isMounted = true;

    async function startSession() {
      if (!cards.length) {
        setStudyCards([]);
        setIsStarting(false);
        return;
      }

      setIsStarting(true);
      setErrorMessage("");

      try {
        const response = await studySessionService.start(deckId);

        if (!isMounted) {
          return;
        }

        setSessionId(response.sessionId);
        setStudyCards(response.flashcards);
        setCurrentIndex(0);
        setIsFlipped(false);
        setCompleted(false);
        setSummary(null);
      } catch (error) {
        if (!isMounted) {
          return;
        }

        setErrorMessage(
          getApiErrorMessage(error, "Unable to start a study session right now."),
        );
      } finally {
        if (isMounted) {
          setIsStarting(false);
        }
      }
    }

    void startSession();

    return () => {
      isMounted = false;
    };
  }, [deckId, cards.length]);

  function resetCardFace() {
    setIsFlipped(false);
  }

  function handlePrev() {
    if (currentIndex === 0 || isSubmitting) {
      return;
    }

    resetCardFace();
    setCurrentIndex((value) => value - 1);
  }

  function handleNext() {
    if (currentIndex >= studyCards.length - 1 || isSubmitting) {
      return;
    }

    resetCardFace();
    setCurrentIndex((value) => value + 1);
  }

  async function handleRate(rating: ReviewRating) {
    if (!sessionId || !currentCard || isSubmitting) {
      return;
    }

    setIsSubmitting(true);
    setErrorMessage("");

    try {
      await studySessionService.submitCard(sessionId, {
        flashcardId: currentCard.id,
        orderIndex: currentIndex + 1,
        rating,
      });

      resetCardFace();

      if (currentIndex >= studyCards.length - 1) {
        const finishResponse = await studySessionService.finish(sessionId);
        setSummary(finishResponse);
        setCompleted(true);
        return;
      }

      setCurrentIndex((value) => value + 1);
    } catch (error) {
      setErrorMessage(
        getApiErrorMessage(error, "Unable to submit this card result right now."),
      );
    } finally {
      setIsSubmitting(false);
    }
  }

  async function restart() {
    if (isSubmitting) {
      return;
    }

    setSessionId(null);
    setCurrentIndex(0);
    setIsFlipped(false);
    setCompleted(false);
    setSummary(null);
    setErrorMessage("");
    setIsStarting(true);

    try {
      const response = await studySessionService.start(deckId);
      setSessionId(response.sessionId);
      setStudyCards(response.flashcards);
    } catch (error) {
      setErrorMessage(
        getApiErrorMessage(error, "Unable to restart the study session."),
      );
    } finally {
      setIsStarting(false);
    }
  }

  if (isStarting) {
    return (
      <div className="rounded-[2rem] border border-white/70 bg-white/92 p-10 shadow-[0_28px_80px_rgba(15,23,42,0.12)]">
        <p className="text-sm text-slate-500">Starting study session...</p>
      </div>
    );
  }

  if (errorMessage && !currentCard && !completed) {
    return (
      <div className="rounded-[2rem] border border-rose-200 bg-rose-50 p-8 text-rose-700 shadow-[0_20px_50px_rgba(15,23,42,0.06)]">
        {errorMessage}
      </div>
    );
  }

  if (!studyCards.length) {
    return (
      <div className="rounded-[2rem] border border-dashed border-slate-300 bg-white/80 p-10 text-center shadow-[0_20px_50px_rgba(15,23,42,0.06)]">
        <p className="text-sm leading-8 text-slate-600">
          There are no cards in this study session yet.
        </p>
      </div>
    );
  }

  if (completed && summary) {
    return (
      <motion.div
        animate={{ opacity: 1, scale: 1 }}
        className="rounded-[2rem] border border-white/70 bg-white/92 p-10 text-center shadow-[0_28px_80px_rgba(15,23,42,0.12)]"
        initial={{ opacity: 0, scale: 0.96 }}
      >
        <span className="text-6xl">🎉</span>
        <h2 className="mt-6 text-4xl font-semibold tracking-tight text-slate-950">
          Study session complete
        </h2>
        <p className="mt-4 text-base leading-8 text-slate-600">
          You reviewed {summary.reviewedCards} / {summary.totalCards} cards in {deckTitle}.
        </p>

        <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <div className="rounded-[1.35rem] bg-rose-50 px-5 py-4">
            <p className="text-xs font-semibold uppercase tracking-[0.22em] text-rose-500">
              Again
            </p>
            <p className="mt-2 text-2xl font-semibold text-rose-700">
              {summary.againCount}
            </p>
          </div>
          <div className="rounded-[1.35rem] bg-amber-50 px-5 py-4">
            <p className="text-xs font-semibold uppercase tracking-[0.22em] text-amber-500">
              Hard
            </p>
            <p className="mt-2 text-2xl font-semibold text-amber-700">
              {summary.hardCount}
            </p>
          </div>
          <div className="rounded-[1.35rem] bg-emerald-50 px-5 py-4">
            <p className="text-xs font-semibold uppercase tracking-[0.22em] text-emerald-500">
              Good
            </p>
            <p className="mt-2 text-2xl font-semibold text-emerald-700">
              {summary.goodCount}
            </p>
          </div>
          <div className="rounded-[1.35rem] bg-cyan-50 px-5 py-4">
            <p className="text-xs font-semibold uppercase tracking-[0.22em] text-cyan-500">
              Easy
            </p>
            <p className="mt-2 text-2xl font-semibold text-cyan-700">
              {summary.easyCount}
            </p>
          </div>
        </div>

        <div className="mt-8 flex justify-center">
          <Button className="min-h-13 gap-2" onClick={() => void restart()} type="button">
            <RotateCcw size={16} />
            Study again
          </Button>
        </div>
      </motion.div>
    );
  }

  return (
    <div className="mx-auto flex w-full max-w-3xl flex-col gap-8">
      <div className="space-y-3">
        <div className="flex items-center justify-between text-sm font-medium text-slate-600">
          <span>
            Card {currentIndex + 1} / {studyCards.length}
          </span>
          <span>Session #{sessionId ?? "-"}</span>
        </div>

        <div className="h-3 overflow-hidden rounded-full bg-slate-200/80">
          <motion.div
            animate={{ width: `${((currentIndex + 1) / studyCards.length) * 100}%` }}
            className="h-full rounded-full bg-[linear-gradient(90deg,#205781_0%,#33d1b1_100%)]"
            initial={{ width: 0 }}
          />
        </div>
      </div>

      {errorMessage ? (
        <div className="rounded-[1.35rem] border border-rose-200 bg-rose-50 px-5 py-4 text-sm text-rose-700">
          {errorMessage}
        </div>
      ) : null}

      <div
        className="aspect-[4/3] w-full [perspective:1200px]"
        onClick={() => setIsFlipped((value) => !value)}
      >
        <AnimatePresence mode="wait">
          <motion.div
            key={`${currentCard.id}-${isFlipped ? "back" : "front"}`}
            animate={{ opacity: 1, rotateY: 0 }}
            className="h-full cursor-pointer"
            exit={{ opacity: 0, rotateY: isFlipped ? 90 : -90 }}
            initial={{ opacity: 0, rotateY: isFlipped ? -90 : 90 }}
            transition={{ duration: 0.28, ease: "easeInOut" }}
          >
            {!isFlipped ? (
              <div className="flex h-full flex-col justify-between rounded-[2.2rem] border border-white/70 bg-[linear-gradient(180deg,#ffffff_0%,#eef7ff_100%)] p-8 shadow-[0_28px_80px_rgba(15,23,42,0.12)]">
                <div className="flex items-center justify-between">
                  <span className="rounded-full bg-[#205781]/10 px-4 py-2 text-xs font-semibold uppercase tracking-[0.24em] text-[#205781]">
                    Tap to reveal
                  </span>
                  <span className="text-sm font-medium text-slate-500">
                    {currentCard.frontContentType}
                  </span>
                </div>

                <div className="flex flex-1 items-center justify-center">
                  {currentCard.frontContentType === "IMAGE" && currentCard.frontImageUrl ? (
                    <img
                      alt={currentCard.backText}
                      className="max-h-full max-w-full rounded-[1.6rem] object-cover shadow-[0_24px_45px_rgba(15,23,42,0.16)]"
                      src={currentCard.frontImageUrl}
                    />
                  ) : (
                    <h3 className="text-center text-4xl font-semibold tracking-tight text-slate-950 sm:text-6xl">
                      {currentCard.frontText}
                    </h3>
                  )}
                </div>

                <p className="text-center text-sm text-slate-500">
                  Front side of the card. Flip when you are ready.
                </p>
              </div>
            ) : (
              <div className="flex h-full flex-col rounded-[2.2rem] border border-[#205781]/15 bg-[linear-gradient(180deg,#f8fbff_0%,#ffffff_100%)] p-8 shadow-[0_28px_80px_rgba(15,23,42,0.12)]">
                <div className="flex items-center justify-between">
                  <span className="rounded-full bg-emerald-100 px-4 py-2 text-xs font-semibold uppercase tracking-[0.24em] text-emerald-700">
                    Answer
                  </span>
                  <span className="text-sm font-medium text-slate-500">
                    Tap to flip back
                  </span>
                </div>

                <div className="mt-8 flex-1 space-y-6">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-[0.22em] text-slate-500">
                      Meaning
                    </p>
                    <h3 className="mt-3 text-3xl font-semibold tracking-tight text-slate-950 sm:text-5xl">
                      {currentCard.backText}
                    </h3>
                  </div>

                  {currentCard.exampleText ? (
                    <div className="rounded-[1.5rem] border border-slate-200 bg-slate-50/90 p-5">
                      <p className="text-xs font-semibold uppercase tracking-[0.22em] text-slate-500">
                        Example
                      </p>
                      <p className="mt-3 text-base leading-8 text-slate-700">
                        {currentCard.exampleText}
                      </p>
                    </div>
                  ) : null}

                  {currentCard.noteText ? (
                    <div className="rounded-[1.5rem] border border-[#205781]/12 bg-[#205781]/5 p-5">
                      <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#205781]">
                        Note
                      </p>
                      <p className="mt-3 text-sm leading-7 text-slate-700">
                        {currentCard.noteText}
                      </p>
                    </div>
                  ) : null}
                </div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <button
          className="min-h-14 rounded-[1.35rem] bg-rose-50 px-6 text-sm font-semibold text-rose-700 transition hover:bg-rose-100 disabled:opacity-60"
          disabled={isSubmitting}
          onClick={(event) => {
            event.stopPropagation();
            void handleRate("AGAIN");
          }}
          type="button"
        >
          Again
        </button>

        <button
          className="min-h-14 rounded-[1.35rem] bg-amber-50 px-6 text-sm font-semibold text-amber-700 transition hover:bg-amber-100 disabled:opacity-60"
          disabled={isSubmitting}
          onClick={(event) => {
            event.stopPropagation();
            void handleRate("HARD");
          }}
          type="button"
        >
          Hard
        </button>

        <button
          className="min-h-14 rounded-[1.35rem] bg-emerald-50 px-6 text-sm font-semibold text-emerald-700 transition hover:bg-emerald-100 disabled:opacity-60"
          onClick={(event) => {
            event.stopPropagation();
            void handleRate("GOOD");
          }}
          type="button"
        >
          Good
        </button>

        <button
          className="min-h-14 rounded-[1.35rem] bg-cyan-50 px-6 text-sm font-semibold text-cyan-700 transition hover:bg-cyan-100 disabled:opacity-60"
          disabled={isSubmitting}
          onClick={(event) => {
            event.stopPropagation();
            void handleRate("EASY");
          }}
          type="button"
        >
          Easy
        </button>
      </div>

      <div className="flex justify-center gap-3">
        <Button
          className="min-h-11 gap-2"
          disabled={currentIndex === 0 || isSubmitting}
          onClick={handlePrev}
          type="button"
          variant="secondary"
        >
          <ChevronLeft size={16} />
          Previous
        </Button>
        <Button
          className="min-h-11 gap-2"
          disabled={currentIndex === studyCards.length - 1 || isSubmitting}
          onClick={handleNext}
          type="button"
          variant="secondary"
        >
          Next
          <ChevronRight size={16} />
        </Button>
      </div>
    </div>
  );
}