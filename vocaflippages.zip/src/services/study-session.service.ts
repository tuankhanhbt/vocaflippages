import { apiClient } from "@/lib/axios";
import type {
  FinishStudySessionResponse,
  StartStudySessionResponse,
  SubmitStudyCardPayload,
} from "@/types/flashcard";

async function start(setId: number | string) {
  const response = await apiClient.post<StartStudySessionResponse>(
    `/api/study-sessions/flashcard-sets/${setId}/start`,
  );

  return response.data;
}

async function submitCard(
  sessionId: number | string,
  payload: SubmitStudyCardPayload,
) {
  await apiClient.post(`/api/study-sessions/${sessionId}/cards`, payload);
}

async function finish(sessionId: number | string) {
  const response = await apiClient.put<FinishStudySessionResponse>(
    `/api/study-sessions/${sessionId}/finish`,
  );

  return response.data;
}

export const studySessionService = {
  start,
  submitCard,
  finish,
};